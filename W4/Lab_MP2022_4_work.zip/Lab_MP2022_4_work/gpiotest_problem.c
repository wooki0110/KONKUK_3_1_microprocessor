/******************************************************************************
Copyright (c) 2017 SoC Design Laboratory, Konkuk University, South Korea
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met: redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer;
redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution;
neither the name of the copyright holders nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Authors: Jooho Wang (joohowang@konkuk.ac.kr)

Revision History
2018.03.31: Started by Jooho Wang

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <xtime_l.h>
#include "xparameters.h"
#include "xgpio.h"
//#include "xutil.h"

#define N 100

//===================================================

void delay()
{
	int  u = 0, c = 0, p = 0;
	for (u=0; u<9999999; u++);
		for (c=0; c<9999999; c++);
			for (p=0; p<9999999; p++);
}


typedef enum main_state {
	RESET = 0x1, RUN = 0x2, STOP_RESUME = 0x4, RECORD = 0x8, DISPLAY = 0x10
}STATE;


int main (void)
{
	XGpio dip, push, led;

	int next_state = RESET, curr_state = RESET;
	int timer = 0, lap_index = 0;
	int psb = 0, dp = 0;
	int lap[N] = {0,}, i = 0;

	xil_printf("-- Start of the Program --\r\n");

	XGpio_Initialize(&dip, XPAR_SWS_4BITS_DEVICE_ID);
	XGpio_SetDataDirection(&dip, 1, 0xffffffff);

	XGpio_Initialize(&push, XPAR_BTNS_4BITS_DEVICE_ID);
	XGpio_SetDataDirection(&push, 1, 0xffffffff);

	XGpio_Initialize(&led, XPAR_LEDS_4BITS_DEVICE_ID);
	XGpio_SetDataDirection(&led, 1, 0x00000000);

	while(1)
	{
		//Fill your code here
	}; 

	return 0;
}
