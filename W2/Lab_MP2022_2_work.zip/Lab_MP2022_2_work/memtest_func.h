/******************************************************************************
Copyright (c) 2017 SoC Design Laboratory, Konkuk University, South Korea
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met: redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer;
redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution;
neither the name of the copyright holders nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Authors: Sunwoo Kim (sunwkim@konkuk.ac.kr)

Revision History
2018.03.19: Started by Sunwoo Kim

*******************************************************************************/

#ifndef MEMTEST_FUNC_H_
#define MEMTEST_FUNC_H_

#include <xtime_l.h>
XTime xstart, xstop;
float func_time;


int memtest_example()
{
	int i,flag=-1;
	int *Addr;

	int Pattern = 0xAAAA5555;

	print ("Test example :");

	XTime_GetTime(&xstart);

	flag = 0;
	Addr = 0x10100000;
	// Memory write
	for (i=0; i<1024;i++)
	{
		Addr[i] = Pattern;
	}

	// Memory Read & Check
	for (i=0; i<1024;i++)
	{
		if (Addr[i] != Pattern)
		{
			flag = -1;
			break;
		}
	}

	XTime_GetTime(&xstop);
	func_time = (float)(xstop - xstart) / 333;
	printf("%f us\n",func_time);

	return flag;
}


int memtest_0()
{
	int i,flag=-1;
	int *Addr;

	int Pattern = 0xAAAA5555;

	print ("Test 0 :");

	XTime_GetTime(&xstart);

	//////////////////////////////
	//// Fill your code here! ////
	//////////////////////////////

	XTime_GetTime(&xstop);
	func_time = (float)(xstop - xstart) / 333;
	printf("%f us\n",func_time);

	return flag;
}


int memtest_1()
{
	int i,flag=-1;
	short *Addr;

	short Pattern0;
	short Pattern1;

	print ("Test 1 :");

	XTime_GetTime(&xstart);

	//////////////////////////////
	//// Fill your code here! ////
	//////////////////////////////

	XTime_GetTime(&xstop);
	func_time = (float)(xstop - xstart) / 333;
	printf("%f us\n",func_time);

	return flag;
}


int memtest_2()
{
	int i,flag=-1;
	short *Addr;
	int Word;

	print ("Test 2 :");


	XTime_GetTime(&xstart);

	//////////////////////////////
	//// Fill your code here! ////
	//////////////////////////////

	XTime_GetTime(&xstop);
	func_time = (float)(xstop - xstart) / 333;
	printf("%f us\n",func_time);

	return flag;
}


#endif /* MEMTEST_FUNC_H_ */
