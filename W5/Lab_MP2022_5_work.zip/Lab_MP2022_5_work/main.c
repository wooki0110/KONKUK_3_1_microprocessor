/******************************************************************************
Copyright (c) 2017 SoC Design Laboratory, Konkuk University, South Korea
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met: redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer;
redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution;
neither the name of the copyright holders nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Authors: Jooho Wang (joohowang@konkuk.ac.kr)

Revision History
2017.11.11: Started by Jooho Wang
2018.04.30: Revised by Jooho Wang 
 - Changed the variable name.
2018.05.28: Revised by Sunwoo Kim
 - Changed Funtions
*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "benchmarking.h"

/* N should be power of 2, and larger than T */
#define N			  512

/* T should be power of 2 */
#define T			   2

#define TEST_ROUNDS    10

#define NR_BENCHMARK_CASE 2



unsigned initializor_dummy(unsigned int uiParam0, unsigned int uiParam1, unsigned int uiParam2, unsigned int uiParam3 )
{
	int *p = (int *)uiParam0;
	int i,j;

	for(i=0;i<N;i++)
		for(j=0;j<N;j++)
            *(p+i*N+j) = 0;

	return 1;
}

unsigned validator_dummy(unsigned int uiParam0, unsigned int uiParam1, unsigned int uiParam2, unsigned int uiParam3 )
{
	return 1;
}



int a[N][N],b[N][N],result1[N][N],result2[N][N];

unsigned mat_mult(unsigned int uiParam0, unsigned int uiParam1, unsigned int uiParam2, unsigned int uiParam3 )
{
	int i,j,k;

	//////////////////////////////
	//// Fill your code here! ////
	//////////////////////////////
}

unsigned mat_mult_tiling(unsigned int uiParam0, unsigned int uiParam1, unsigned int uiParam2, unsigned int uiParam3 )
{
	int io,jo,ko,ii,ki,ji;
	int *rresult, *rb, *ra;

	//////////////////////////////
	//// Fill your code here! ////
	//////////////////////////////
}


int main()
{
	unsigned int i,j;
	int iRetCode;

	BENCHMARK_CASE *pBenchmarkCase;
	BENCHMARK_STATISTICS *pStat;

	//Xil_L1DCacheDisable();

	printf("----Benchmarking starting----\r\n");
	printf("CPU_FREQ_HZ=%d, TIMER_FREQ_HZ=%d\r\n", 
			CPU_FREQ_HZ, CPU_FREQ_HZ/2/(TIMER_PRE_SCALE+1));
	printf("Matrix size= %d * %d\r\n", N, N);

	// We need to validate the algorithm's correctness
	for(i=0;i<N;i++)
		for(j=0;j<N;j++)
		{
		    a[i][j]=i*1+j*2;
		    b[i][j]=i*2+j*3;
		    result1[i][j]=0;
		    result2[i][j]=0;
		}

	mat_mult(0,0,0,0);
	mat_mult_tiling(0,0,0,0);

	iRetCode=memcmp(result1, result2, N*N*sizeof(unsigned int) );
	if(iRetCode==0)
	    printf("Algorithm validation success!\r\n" );
	else {
	    printf("Algorithm validation failed! Exit application.\r\n" );
	    return -1;
	}


	BENCHMARK_CASE BenchmarkCases[NR_BENCHMARK_CASE] = {
			{"Non-cache optimized matrix multiply", TEST_ROUNDS, initializor_dummy,
					mat_mult, {(unsigned int)result1,0,0,0}, 0, validator_dummy},
			{"Cache optimized matrix multiply",     TEST_ROUNDS, initializor_dummy,
					mat_mult_tiling, {(unsigned int)result2,0,0,0}, 0, validator_dummy}
	};

    // Now we can collect the execution time statistics
    for(i=0;i<NR_BENCHMARK_CASE;i++)
    {
    	pBenchmarkCase = &BenchmarkCases[i];
    	pStat = &(pBenchmarkCase->stat);
    	printf("Case %d: %s\r\n", i, pBenchmarkCase->pName);
    	run_benchmark_single(pBenchmarkCase);
    	statistics_print(pStat);
    }
    printf("----Benchmarking Complete----\r\n");

	return 0;
}















